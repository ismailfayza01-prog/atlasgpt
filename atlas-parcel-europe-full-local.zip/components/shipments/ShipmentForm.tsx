"use client";

import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { generateTrackingCode } from "@/lib/tracking";
import type { ShipmentStatus } from "@/lib/types";

export type ShipmentDraft = {
  tracking_code: string;
  origin: string;
  destination: string;
  weight_kg: number;
  price_amount: number;
  currency: string;
  status: ShipmentStatus;
  notes: string;
  customer_email: string;
};

export function ShipmentForm({
  initial,
  onSubmit,
  submitLabel,
}: {
  initial?: Partial<ShipmentDraft>;
  onSubmit: (d: ShipmentDraft) => Promise<void>;
  submitLabel: string;
}) {
  const [d, setD] = React.useState<ShipmentDraft>({
    tracking_code: initial?.tracking_code ?? generateTrackingCode(),
    origin: initial?.origin ?? "",
    destination: initial?.destination ?? "",
    weight_kg: initial?.weight_kg ?? 1,
    price_amount: initial?.price_amount ?? 0,
    currency: initial?.currency ?? "MAD",
    status: initial?.status ?? "created",
    notes: initial?.notes ?? "",
    customer_email: initial?.customer_email ?? "",
  });
  const [busy, setBusy] = React.useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    await onSubmit(d);
    setBusy(false);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <div className="grid gap-3 md:grid-cols-2">
        <div>
          <div className="text-xs mb-1 text-zinc-600">Tracking code</div>
          <Input value={d.tracking_code} onChange={(e) => setD(v => ({ ...v, tracking_code: e.target.value }))} />
          <div className="mt-1 text-xs text-zinc-500">
            Tip: keep stable. Used by public tracking.
          </div>
        </div>
        <div>
          <div className="text-xs mb-1 text-zinc-600">Customer email (optional)</div>
          <Input value={d.customer_email} onChange={(e) => setD(v => ({ ...v, customer_email: e.target.value }))} placeholder="customer@example.com" />
          <div className="mt-1 text-xs text-zinc-500">
            If email exists, shipment is assigned to that user.
          </div>
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <div>
          <div className="text-xs mb-1 text-zinc-600">Origin</div>
          <Input value={d.origin} onChange={(e) => setD(v => ({ ...v, origin: e.target.value }))} required />
        </div>
        <div>
          <div className="text-xs mb-1 text-zinc-600">Destination</div>
          <Input value={d.destination} onChange={(e) => setD(v => ({ ...v, destination: e.target.value }))} required />
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-4">
        <div>
          <div className="text-xs mb-1 text-zinc-600">Weight (kg)</div>
          <Input value={d.weight_kg} onChange={(e) => setD(v => ({ ...v, weight_kg: Number(e.target.value) }))} type="number" min={0} step="0.1" />
        </div>
        <div>
          <div className="text-xs mb-1 text-zinc-600">Price</div>
          <Input value={d.price_amount} onChange={(e) => setD(v => ({ ...v, price_amount: Number(e.target.value) }))} type="number" min={0} step="0.01" />
        </div>
        <div>
          <div className="text-xs mb-1 text-zinc-600">Currency</div>
          <Input value={d.currency} onChange={(e) => setD(v => ({ ...v, currency: e.target.value }))} />
        </div>
        <div>
          <div className="text-xs mb-1 text-zinc-600">Status</div>
          <select
            className="h-10 w-full rounded-xl border border-zinc-200 bg-white px-3 text-sm"
            value={d.status}
            onChange={(e) => setD(v => ({ ...v, status: e.target.value as any }))}
          >
            {["requested","created","picked_up","in_transit","out_for_delivery","delivered","cancelled"].map(s => (
              <option key={s} value={s}>{s.replaceAll("_"," ")}</option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <div className="text-xs mb-1 text-zinc-600">Notes</div>
        <textarea
          className="min-h-[80px] w-full rounded-xl border border-zinc-200 bg-white px-3 py-2 text-sm outline-none focus:border-zinc-400"
          value={d.notes}
          onChange={(e) => setD(v => ({ ...v, notes: e.target.value }))}
        />
      </div>

      <div className="flex items-center justify-between">
        <Button type="button" variant="secondary" onClick={() => setD(v => ({ ...v, tracking_code: generateTrackingCode() }))}>
          Generate code
        </Button>
        <Button type="submit" disabled={busy}>{busy ? "Saving…" : submitLabel}</Button>
      </div>
    </form>
  );
}
